package xoGAME;

public class PlayTheGame {

	public static void main(String[] args) {//In main we built a new board

		Board new_Board=new Board();
		new_Board.The_first_turn();


	}

}
